package com.group6.Rental_Car.services.scheduler;

public interface OrderMaintenanceService {
    void autoCancelPendingOrders();
}