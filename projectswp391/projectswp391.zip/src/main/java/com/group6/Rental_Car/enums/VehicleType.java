package com.group6.Rental_Car.enums;

public enum VehicleType {
    RENTAL,
    AVAILABLE,
    MAINTENANCE
}

