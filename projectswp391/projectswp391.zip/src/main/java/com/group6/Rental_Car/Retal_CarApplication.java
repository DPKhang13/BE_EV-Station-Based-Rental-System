package com.group6.Rental_Car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Retal_CarApplication {

    public static void main(String[] args) {
        SpringApplication.run(Retal_CarApplication.class, args);
    }

}