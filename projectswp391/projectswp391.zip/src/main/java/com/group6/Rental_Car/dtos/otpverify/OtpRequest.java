package com.group6.Rental_Car.dtos.otpverify;


import lombok.Data;

@Data
public class OtpRequest {
    private String otp;
}
