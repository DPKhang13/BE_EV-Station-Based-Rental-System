package com.group6.Rental_Car.enums;

public enum UserStatus {
    ACTIVE,
    NEED_OTP,
    VERIFIED
    }
