package com.group6.Rental_Car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projectswp391ApplicationTests {

    @Test
    void contextLoads() {
    }

}
