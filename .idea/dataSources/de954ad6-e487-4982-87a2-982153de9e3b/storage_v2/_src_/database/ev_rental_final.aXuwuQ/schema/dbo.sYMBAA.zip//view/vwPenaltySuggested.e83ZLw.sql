CREATE VIEW dbo.vwPenaltySuggested AS
SELECT p.penalty_id, p.order_id, p.[name], p.[description], p.fee,
       p.category, p.severity, p.[unit], p.qty, p.unit_price, p.min_fee, p.max_fee,
       pol.default_unit_price, pol.default_min_fee, pol.default_max_fee,
       CASE
         WHEN p.[unit] IS NOT NULL AND p.qty IS NOT NULL
              THEN CAST(p.qty * COALESCE(p.unit_price, pol.default_unit_price) AS DECIMAL(12,0))
         WHEN COALESCE(p.min_fee, pol.default_min_fee) IS NOT NULL
              AND COALESCE(p.max_fee, pol.default_max_fee) IS NOT NULL
              AND COALESCE(p.min_fee, pol.default_min_fee) = COALESCE(p.max_fee, pol.default_max_fee)
              THEN COALESCE(p.min_fee, pol.default_min_fee)
         ELSE NULL
       END AS suggested_fee
FROM dbo.Penalty p
LEFT JOIN dbo.PenaltyPolicy pol ON p.policy_id = pol.policy_id;
go

