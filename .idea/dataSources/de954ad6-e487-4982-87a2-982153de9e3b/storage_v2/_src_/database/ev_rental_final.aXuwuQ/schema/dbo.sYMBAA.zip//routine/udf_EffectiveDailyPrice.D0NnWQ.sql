CREATE FUNCTION dbo.udf_EffectiveDailyPrice
(
    @vehicle_id INT,
    @forDate    DATE
)
RETURNS DECIMAL(12,0)
AS
BEGIN
    DECLARE @base  DECIMAL(12,0),
            @surch DECIMAL(12,0);

    SELECT @base = daily_price, @surch = weekend_daily_surcharge
    FROM PricingRule WHERE vehicle_id = @vehicle_id;

    IF (@base IS NULL) RETURN NULL;

    IF (DATENAME(WEEKDAY, @forDate) IN ('Saturday','Sunday')
        OR EXISTS (SELECT 1 FROM HolidayDates h WHERE h.[date] = @forDate))
        RETURN @base + @surch;

    RETURN @base;
END;
go

